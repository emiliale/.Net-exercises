﻿using static System.Console;

namespace TestHello
{

    public class Program    
    {
        public static void Main(string[] args) 
        {
            WriteLine("Hello World!");
        }
    }
}
