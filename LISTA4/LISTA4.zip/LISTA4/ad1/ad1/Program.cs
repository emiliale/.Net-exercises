﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ad1
{
    class Program
    {
        static void Main(string[] args)
        {
            MessageBox.Show("Witaj Świecie!");
            Console.WriteLine("Hello World!");
           
        }
    }
}
